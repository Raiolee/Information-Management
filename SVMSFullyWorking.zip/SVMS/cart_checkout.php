<?php
require_once 'config/connection.php';
$connection = mysqli_connect(HOST_NAME, USER_NAME, PASSWORD, DB_NAME);

if (!$connection) {
    die("Database connection failed: " . mysqli_connect_error());
}

error_reporting(E_ERROR | E_PARSE);

$errors = array();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $totalAmount = 0;
    $query = "SELECT * FROM cart";
    $result = mysqli_query($connection, $query);

    while ($row = mysqli_fetch_assoc($result)) {
        $productId = $row['id'];
        $quantityName = 'quantity_' . $productId;
        $totalAmount += $row['price'] * $_POST[$quantityName];
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <?php include('includes/homepageheader.php'); ?>
    <style>
        table,
        th,
        tr {
            text-align: left;
        }

        h2 {
            text-align: center;
            background-color: #efefef;
            padding: 2%;
        }

        table th {
            background-color: #efefef;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>Checkout</h2>
        <table class="table">
            <thead>
                <tr>
                    <th width="20%"></th>
                    <th width="20%">Product Name</th>
                    <th width="20%">Quantity</th>
                    <th width="20%">Price Details</th>
                    <th width="20%">Total Price</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $query = "SELECT * FROM cart";
                $result = mysqli_query($connection, $query);
                while ($row = mysqli_fetch_assoc($result)) {
                ?>
                    <tr>
                        <td><?php echo $row['product_name']; ?></td>
                        <td><?php echo $row['product_name']; ?></td>
                        <td><?php echo $row['quantity']; ?></td>
                        <td>₱<?php echo $row['price']; ?></td>
                        <td>₱<?php echo number_format($row['price'] * $row['quantity'], 2); ?></td>
                    </tr>
                <?php
                }
                ?>
            </tbody>
        </table>
        <table class="table">
            <thead>
                <tr>
                    <th width="20%"></th>
                    <th width="20%"></th>
                    <th width="20%"></th>
                    <th width="20%"></th>
                    <th width="20%"></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td>Free Shipping Fee: ₱0.00</td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><h7 id="totalAmount">Total Amount: ₱<?= number_format($totalAmount, 2) ?></h7></td>
                </tr>
            </tbody>
        </table>
    </div>

    

            <div class="text-center mt-3">
                <button type="submit" class="btn btn-outline-success mx-2" name="submitOrder">Submit Order</button>
            </div>
        </form>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/@popperjs/core@2"></script>
    <script>
        $(document).ready(function () {
            function updateTotalAmount() {
                $.ajax({
                    type: 'POST',
                    url: 'cart_updatetotal.php',
                    success: function (response) {
                        $('#totalAmount').html('Total Amount: ₱' + response);
                    }
                });
            }
            updateTotalAmount();
            setInterval(updateTotalAmount, 5000);
        });
    </script>
    <?php include('includes/footer.html'); ?>
</body>

</html>
